-------
INSTALL
-------
1. Click on the file "animation.html" to play the animation

** Music **

1. If you place a music file named "music.mid" in the same directory
   as "animation.html", it will be played automatically through "animation.html". 
